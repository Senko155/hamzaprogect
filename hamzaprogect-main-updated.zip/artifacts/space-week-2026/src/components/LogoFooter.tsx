export default function LogoFooter() {
  return (
    <footer className="logo-footer" aria-label="شعارات الجهات المشاركة" data-testid="logo-footer">
      <img src="/logos/logo1.webp" alt="" width={362} height={275} loading="lazy" decoding="async" fetchPriority="low" />
      <img src="/logos/logo2.webp" alt="" width={1200} height={327} loading="lazy" decoding="async" fetchPriority="low" />
    </footer>
  );
}
