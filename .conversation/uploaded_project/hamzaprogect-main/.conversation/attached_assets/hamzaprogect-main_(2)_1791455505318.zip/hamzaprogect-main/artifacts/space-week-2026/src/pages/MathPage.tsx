import { Atom } from 'lucide-react';
import SectionPlaceholder from './SectionPlaceholder';

export default function MathPage() {
  return (
    <SectionPlaceholder
      section="math"
      number="03 / SPACE & NUMBER"
      title="رياضيات المدار"
      lead="المعادلات ليست أرقاماً مجردة؛ إنها الطريقة التي ترسم بها الطبيعة طريقها."
      hint="مساحة المعادلات ستُفتح قريباً."
      icon={Atom}
    />
  );
}
