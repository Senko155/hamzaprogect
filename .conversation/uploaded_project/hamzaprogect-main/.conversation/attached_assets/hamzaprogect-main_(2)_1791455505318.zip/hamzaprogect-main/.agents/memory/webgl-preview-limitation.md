---
name: WebGL preview limitation
description: Replit screenshot browser cannot initialize WebGL in this workspace.
---

The screenshot browser in this workspace failed to create a WebGL context while the app itself served normally and its 2D solar-system fallback rendered.

**Why:** The preview reported `BindToCurrentSequence failed`, while Vite started successfully and the fallback was visible at desktop and phone sizes.

**How to apply:** For WebGL features, verify the application build and fallback independently. Do not treat this screenshot-browser renderer error alone as proof the app failed, and be clear that WebGL-specific visuals were not visually verified when this limitation appears.
